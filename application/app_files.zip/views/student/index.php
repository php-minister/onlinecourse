<?php $this->load->view('layout/header_web',array('page_title'=>$this->lang->line('scheduler'),'calendar_new'=>TRUE,'forms'=>TRUE , 'page_name' => 'Students' , 'page_style' => 'students_home')) ?>

<div id="student_schedule_page">
<?php $this->load->view('student/menu',array('active_menu'=>'scheduler'))?>
<script>
    var calendar;
    $('document').ready(function(){
         calendar = $('#student_calendar_new').calendario({
                        /*onDayClick : function($el,$contentEl,dateProperties) {                          
						    var events = calendar.getDate(dateProperties);
						    if (events)
                            {
                                $("#day_scheduling .modal-body").html(events);
                                $("#day_scheduling h3").html(dateProperties.day+' '+dateProperties.monthname+', '+dateProperties.weekdayname);
                                $('#day_scheduling').modal('show');
                            }
                        },*/
                        afterEventTitleRender:function(event,date){
                          return (new Date()>new Date(date+' '+event.end))?('&nbsp;&nbsp;&nbsp;<a href="student/left_comment/'+event.id+'" class="btn btn-mini '+(event.is_commented=='0'?'btn-info':'')+'" onclick="$(\'#day_scheduling\').modal(\'hide\')" data-target="#waiting_for_response" data-toggle="modal" title="<?= $this->lang->line('leave_feedback')?>"><span class="icon-thumbs-up '+(event.is_commented=='0'?'icon-white':'')+'"></span></a>'):'';
                        },
                        caldata : <?= $scheduling?>,
                        weeks:[<?= $this->lang->line('weeks')?>],
                        weekabbrs:[<?= $this->lang->line('weekabbrs')?>],
                        months:[<?= $this->lang->line('months')?>],
                        monthabbrs:[<?= $this->lang->line('monthabbrs')?>]

		   })						

			$('.trigger_class').click(function(){
				var schedule_id = $(this).attr('id');
				var web_url ='<?= $this->config->item('base_url')?>student/get_particular_schedule/'+schedule_id;

					 $.ajax({ // ajax call starts
							  url: web_url,
							  type: 'post',
							  //data: 'button=' + $(this).val(), // Send value of the clicked button
							  dataType: 'json', // Choosing a JSON datatype
							  success: function(data) // Variable data contains the data we get from serverside
							  {
								  var i=0;
								  dates = '';
								  ul_content = '';
								var comment = '';
								  
								var comment = '&nbsp;&nbsp;&nbsp;<a href="student/left_comment/'+data[i].id+'" class="btn btn-mini '+(data[i].is_commented=='0'?'btn-info':'')+'" onclick="$(\'#day_scheduling\').modal(\'hide\')" data-target="#waiting_for_response" data-toggle="modal" title="<?= $this->lang->line('leave_feedback')?>"><span class="icon-thumbs-up '+(data[i].is_commented=='0'?'icon-white':'')+'"></span></a>';
								
								dates +='<li class="event even"> <div class="time">'+data[i].start_time.replace(/:[0-9]+$/gi,'')+' - '+data[i].end_time.replace(/:[0-9]+$/gi,'')+'</div><div class="title">';
								
								
								 dates += '<span>';
								 
								 dates += data[i].title.split('{|}')[0];
								 
								 dates +='</span>';                       
								 dates +='</div>'+comment+'<div class="clearfix"></div><p class="description">'+data[i].title.replace('{|}', ' ')+'</p></li>';
								 ul_content = '<ul class="day_events">'+dates+'</ul>';
										 

								
								 $("#day_scheduling .modal-body").html(ul_content);
                                //$("#day_scheduling h3").html(dateProperties.day+' '+dateProperties.monthname+', '+dateProperties.weekdayname);
                                $('#day_scheduling').modal('show');										 
										 
														
								 
							  }
						  });				
				
				//ajax function ends
			})	
	   
    });
</script>
<section>
    <article>
        <div class="modal hide" id="day_scheduling" role="dialog" aria-hidden="true">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h3><?= $this->lang->line('date_events')?></h3>
          </div>
          <div class="modal-body"></div>
          <div class="modal-footer">
            <button type="button" class="btn" data-dismiss="modal"><?= $this->lang->line('close')?></button>
          </div>
        </div>
        <div class="custom-calendar-wrap custom-calendar-full">
            <div class="custom-header">
                <h3 class="custom-month-year">
                    <span id="custom-month" class="custom-month"></span>
                    <span id="custom-year" class="custom-year"></span>                    
                    <nav>
                        <span id="custom-prev" class="custom-prev"></span>
                        <span id="custom-next" class="custom-next"></span>
                        <span id="custom-current" class="custom-current"></span>
                    </nav>
						<a href="student/get_schedule" target="_blank" id="download_pdf" title="<?= $this->lang->line('download_pdf')?>">
							<img src="images/pdf.png" style="vertical-align:top;">
                        </a>                                        
                </h3>
                <div class="clearfix"></div>
            </div>
            <div id="student_calendar_new" class="fc-calendar-container"></div>
            <div class="clearfix"></div>
        </div>
    </article>
</section>

</div>
<?php $this->load->view('layout/footer_web')?>