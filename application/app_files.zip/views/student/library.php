<?php $this->load->view('layout/header_web',array('page_title'=>$this->lang->line('library'),'forms'=>TRUE,'tables'=>TRUE)) ?>
<?php $this->load->view('student/menu',array('active_menu'=>'library'))?>
<script>
    $('document').ready(function(){
        $('.dynamicTable').dataTable({"sPaginationType": "full_numbers","bAutoWidth": false,"bLengthChange": false,"oLanguage":<?= $this->lang->line('datatables')?>});
    })
</script>
<!--<header>
    <h2><?= $this->lang->line('library')?></h2>
</header>-->
<section>
    <article>
        <table class="dynamicTable table-bordered table table-condensed table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th><?= $this->lang->line('item')?></th>
                    <th><?= $this->lang->line('uploaded')?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($library as $item){?>
                <tr>
                    <td><?= $item['item_id']?></td>
                    <td>
                        <div class="pull-left margin_right_10 hidden-phone"><a href="student/download/<?= $item['item_id']?>"><img src="images/files/<?= $item['item_extenstion']?>.png"></a></div>
                        <span class="pull-left"><a href="student/download/<?= $item['item_id']?>" class="wrapword"><?= $item['item_file']?></a><br/><i><?= $item['item_description']?></i></span>
                    </td>
                    <td>
                        <?= date('d M Y h:i A',strtotime($item['uploaded']))?>
                        <?= $this->lang->line('by')?> <?= $item['autor_name']?>
                    </td>
                </tr>
                <?php }?>
            </tbody>
        </table>
    </article>
</section>

<?php $this->load->view('layout/footer_web')?>