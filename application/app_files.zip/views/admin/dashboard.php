<?php $this->load->view('layout/header',array('page_title'=>$this->lang->line('dashboard'),'forms'=>TRUE)) ?>
<?php $this->load->view('admin/menu',array('active_menu'=>''))?>
<header>
    <h2><?= $this->lang->line('dashboard')?></h2>
</header>
<section>
    <article>
        <p><?= $this->lang->line('dashboard_is_coming')?></p>
    </article>
</section>
<?php $this->load->view('layout/footer') ?>