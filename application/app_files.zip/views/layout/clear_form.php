<script>
    $('document').ready(function(){
        $('input').val('');
        $('textarea').val('');
    })
</script>