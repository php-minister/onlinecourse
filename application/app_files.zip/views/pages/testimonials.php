<?php $this->load->view('pages/header');?>
			<div role="main" class="main">

	 <section class="page-top caliber">
      <div class="container">
        <div class="row">
          <div class="span12">
            <ul class="breadcrumb">
             <li><a href="<?= $this->config->item('base_url')?>">Home</a> 
              <span class="divider">/</span></li>
              <li><a href="<?= $this->config->item('base_url')?>main/about_us">About Us</a> 
               <span class="divider">/</span></li>
              <li class="active">Testimonials</li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="span10">
            <h2>Testimonials</h2>
          </div>
          <div class="span2"> <img src="<?= $this->config->item('base_url')?>img/flower.png" class="full-im"></div>
        </div>
      </div>
    </section>

				<div class="container">
					<div class="row">
						<div class="span12">
							<h3 class="pull-top">Testimonails </h3>
						</div>
					</div>

					<div class="row">
						<div class="span12">							
                            Coming Soon
							<!--<ul class="timeline">
								<li>
									<div class="thumb">
										<img src="<?= $this->config->item('base_url')?>img/office-4.jpg" alt="" />
									</div>
									<div class="featured-box">
										<div class="box-content">
											<h4><strong>2012</strong></h4>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc vehicula lacinia. Proin adipiscing porta tellus, Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc vehicula lacinia. Proin adipiscing porta tellus,</p>
										</div>
									</div>
								</li>
								<li>
									<div class="thumb">
										<img src="<?= $this->config->item('base_url')?>img/office-3.jpg" alt="" />
									</div>
									<div class="featured-box">
										<div class="box-content">
											<h4><strong>2010</strong></h4>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc vehicula lacinia. Proin adipiscing porta tellus, Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc vehicula lacinia.</p>
										</div>
									</div>
								</li>
								<li>
									<div class="thumb">
										<img src="<?= $this->config->item('base_url')?>img/office-2.jpg" alt="" />
									</div>
									<div class="featured-box">
										<div class="box-content">
											<h4><strong>2005</strong></h4>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc vehicula lacinia. Proin adipiscing porta tellus, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc vehicula lacinia. Proin adipiscing porta tellus, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc vehicula lacinia. Proin adipiscing porta tellus,</p>
										</div>
									</div>
								</li>
								<li>
									<div class="thumb">
										<img src="<?= $this->config->item('base_url')?>img/office-1.jpg" alt="" />
									</div>
									<div class="featured-box">
										<div class="box-content">
											<h4><strong>2000</strong></h4>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc vehicula lacinia. Proin adipiscing porta tellus, Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc vehicula lacinia. Proin adipiscing porta tellus, Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc vehicula lacinia. Proin adipiscing porta tellus,</p>
										</div>
									</div>
								</li>
							</ul>-->
						</div>
					</div>

				</div>

			</div>		
            
<?php $this->load->view('pages/footer');?>            