<html>
<body>

<p>New Contact form has been submitted from website:</p>
<table border="0" width="70%">
<tr>
    <td width="25%">Name:</td>
    <td><b><?php echo $name; ?></b></td>
</tr>
<tr>
    <td>Email address:</td>
    <td><b><?php echo $email; ?></b></td>
</tr>
<tr>
    <td>Subject:</td>
    <td><b><?php echo $subject; ?></b></td>
</tr>
<tr>
    <td>Message:</td>
    <td><b><?php echo $message; ?></b></td>
</tr>
</table>

</body>
</html>