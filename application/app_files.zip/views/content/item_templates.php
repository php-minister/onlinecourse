<?php
  $template['item_name']='<img src="images/files/%s.png" class="pull-left margin_right_10 hidden-phone"><span class="pull-left wrapword">%s<br/><i>%s</i></span>';
  
  $template['item_actions']='<a href="content/edit_library_item/%s" data-target="#waiting_for_response" data-toggle="modal" class="btn btn-mini" title="%s"><i class="icon-edit"></i></a>&nbsp;<button class="btn btn-mini" onclick="delete_item(%s)" title="%s"><i class="icon-remove"></i></button>';
?>