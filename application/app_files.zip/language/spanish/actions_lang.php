<?php 
	$lang['teacher_actions_edit']='<a data-target="#waiting_for_response" data-toggle="modal" class="btn btn-mini" title="Editar profesor" href="teachers/edit/%s"><i class="icon-edit"></i></a>&nbsp;
<a class="btn btn-mini" title="Programación" href="teachers/scheduling/%s"><i class="icon-calendar"></i></a>';
	$lang['teacher_actions_delete']='&nbsp;<button onclick="delete_teacher(%s)" title="Eliminar profesor" class="btn btn-mini"><i class="icon-remove"></i></button>';
	$lang['student_actions_edit']='<a data-target="#waiting_for_response" data-toggle="modal" class="btn btn-mini" title="Editar estudiante" href="students/edit/%s"><i class="icon-edit"></i></a>';
	$lang['student_actions_delete']='&nbsp;<button onclick="delete_student(%s)" title="Eliminar estudiante" class="btn btn-mini"><i class="icon-remove"></i></button>';
	$lang['parents_actions_edit']='<a data-target="#waiting_for_response" data-toggle="modal" class="btn btn-mini" title="Editar padre" href="parents/edit/%s"><i class="icon-edit"></i></a>';
	$lang['parents_actions_delete']='&nbsp;<button onclick="delete_parent(%s)" title="Eliminar padre" class="btn btn-mini"><i class="icon-remove"></i></button>';
	$lang['incident_actions_edit']='<a data-target="#waiting_for_response" data-toggle="modal" class="btn btn-mini" title="Editar incidente" href="incidents/edit/%s"><i class="icon-edit"></i></a>';
	$lang['incident_actions_delete']='&nbsp;<button onclick="delete_incident(%s)" title="Eliminar incidente" class="btn btn-mini"><i class="icon-remove"></i></button>';

 ?>