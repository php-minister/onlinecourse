<?php 
	$lang['can_t_find_grades']='No se pueden encontrar las calificaciones';
	$lang['show_students']='Mostrar estudiantes';
	$lang['can_t_find_subjects']='No se pueden encontrar asignaturas';
	$lang['in']='dentro';
	$lang['starts_at']='empieza en';
	$lang['attendance_1']='Presente';
	$lang['attendance_2']='Ausente';
	$lang['attendance_3']='Ausente con excusa';
	$lang['attendance_4']='Retraso';
	$lang['attendance_5']='Retraso con excusa';
	$lang['no_comments']='Sin comentarios';
	$lang['wrong_attendance_status']='Mal estado de asistencia';

 ?>