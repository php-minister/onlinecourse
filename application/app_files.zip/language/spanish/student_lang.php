<?php 
	$lang['incidents']='Mis incidentes';
	$lang['gradebook']='Mi libro de calificaciones';
	$lang['read_more']='Leer más';
	$lang['hide']='Ocultar';
	$lang['scheduler']='Programar';
	$lang['selected_semester']='Semestre seleccionado';
	$lang['no_grades_yet']='No tiene ningún curso todavía';
	$lang['all_marks']='Todas las calificaciones';

 ?>