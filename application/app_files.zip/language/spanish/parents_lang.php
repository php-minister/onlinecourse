<?php 
	$lang['are_you_sure_want_delete_this_parent_']='¿Está seguro de que desea eliminar este padre?';
	$lang['parent_deleted']='Padre eliminado';
	$lang['add_parent']='Añadir padre';
	$lang['parents_all']="Mostrar ' +iStart+' a '+iEnd+' de '+iTotal+' todos los padres";
	$lang['parents_filtered']="Mostrar ' +iStart+' a '+iEnd+' de '+iTotal+' padres (filtrados desde '+iMax+' padres totales)";
	$lang['new_parent']='Nuevo padre';
	$lang['parent_name']='Nombre del padre';
	$lang['children']='Niño';
	$lang['edit_parent']='Editar padre';
	$lang['delete_parent']='Eliminar padre';
	$lang['parent_not_found']='Padre no encontrado';

 ?>