<?php 
	$lang['are_you_sure_want_delete_this_incident_']='¿Está seguro de que quiere borrar este incidente?';
	$lang['incident_deleted']='Incidente borrado';
	$lang['add_incident']='Añadir incidente';
	$lang['incidents_all']="Mostrar ' +iStart+' a '+iEnd' de '+iTotal+' todos los incidentes";
	$lang['incidents_filtered']="Mostrar '+iStart+' a '+iEnd+' de '+iTotal+' incidentes (filtrados desde '+iMax+' incidentes totales)";
	$lang['edit_incident']='Editar incidente';
	$lang['delete_incident']='Eliminar incidente';
	$lang['taken_actions']='Tomar acciones';
	$lang['reported_by']='Informado por';
	$lang['new_incident']='Nuevo incidente';

 ?>