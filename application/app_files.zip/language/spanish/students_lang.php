<?php 
	$lang['are_you_sure_want_delete_this_student_']='¿Está seguro que desea eliminar a este estudiante?';
	$lang['student_deleted']='Estudiante eliminado';
	$lang['add_student']='Añadir estudiante';
	$lang['students_all']="Mostrando '+iStart+' a '+iEnd+' de '+iTotal+' de todos los estudiantes";
	$lang['students_filtered']="Mostrando '+iStart+' a '+iEnd+' de '+iTotal+' de estudiantes (filtrado desde '+iMax+' del total de estudiantes’)";
	$lang['edit_student']='Editar estudiante';
	$lang['new_student']='Nuevo estudiante';
	$lang['delete_student']='Eliminar estudiante';
	$lang['main']='Principal';
	$lang['details']='Detalles';
	$lang['graduated']='Graduado';
	$lang['left_the_school']='Dejó la escuela';
	$lang['student_name']='Nombre del estudiante';
	$lang['parents']='Padres';
	$lang['previous_group_is']='El grupo anterior es ';
	$lang['student_not_found']='Estudiante no encontrado';

 ?>