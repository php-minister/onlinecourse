<?php 
	$lang['add_fee']='Añadir Tasa';
	$lang['edit_fee']='Editar tasa';
	$lang['delete_fee']='Eliminar tasa';
	$lang['view_payments']='Ver pagos';
	$lang['fee_deleted']='Eliminados';
	$lang['new_fee']='Nueva tasa';
	$lang['fee_active']='Activar';
	$lang['payments_for']='Pagos de:';
	$lang['not_paid']='No pagado aún';
	$lang['payment_deleted']='(Pago eliminado)';
	$lang['transaction_code']='Identificación de la transacción';
	$lang['payment_date']='Fecha del pago';
	$lang['fee_id']='Identificación de la tasa';
	$lang['fee_name']='Nombre de la tasa';
	$lang['until']='Fecha de vencimiento';
	$lang['amount']='Importe';
	$lang['fee_description']='Descripción de la tasa';
	$lang['payers']='Pagadores';
	$lang['one_payer']='Por favor, seleccione al menos un pagador';
	$lang['wrong_payer_type']='Tipo de pagador erróneo';
	$lang['all_sum_in']='Todo resumido en %s';
	$lang['are_you_sure_want_delete_this_fee_']='¿Seguro que desea eliminar esta tasa?';

 ?>