<?php 
	$lang['login']='Login';
	$lang['password']='Contraseña';
	$lang['going_to_dashboard']='Ir al panel de control';
	$lang['login_password_wrong']='Login/ contraseña es incorrecta';

 ?>