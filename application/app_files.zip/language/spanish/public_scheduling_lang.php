<?php 
	$lang['check_start_end_time']='Por favor, compruebe el momento de inicio y de finalización de la lección';
	$lang['start_time_must_be_bigger']='El momento de inicio debe ser más largo que el de finalización';
	$lang['end_time_lower']='El momento de finalización es más pequeño que ahora';
	$lang['room_is_busy']='La clase está ocupada en este momento';
	$lang['teacher_is_busy']='El profesor está ocupado en este momento';
	$lang['grade_is_busy']='El curso está ocupado en este momento';
	$lang['found___free_rooms']='Se encontraron %s clases libres';
	$lang['all_rooms_are_busy']='Todas las clases están ocupadas';
	$lang['lesson_id']='Identificación de la lección';
	$lang['teacher_id']='Identificación del profesor';
	$lang['start_date']='Fecha de inicio';
	$lang['lesson_start']='La lección comienza';
	$lang['lesson_end']='La lección termina';
	$lang['subject']='Asignatura';
	$lang['room']='Clase';
	$lang['lesson_not_removed']='Lección no eliminada';

 ?>