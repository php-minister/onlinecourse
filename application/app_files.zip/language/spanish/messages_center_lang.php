<?php 
	$lang['messages_center']='Centro de mensajes';
	$lang['new_message']='Nuevo mensaje';
	$lang['send_message']='Enviar Mensaje';
	$lang['message']='Mensaje';
	$lang['to_all_teachers']='A todos los profesores';
	$lang['to_all_parents']='A todos los padres';
	$lang['to_all_students']='A todos los estudiantes';
	$lang['all']='Todos';
	$lang['one_recipient']='Por favor, seleccione al menos un receptor';
	$lang['message_sent']='Mensaje enviado';
	$lang['last_message']='Último mensaje';
	$lang['by']='bor';
	$lang['at']='en';
	$lang['write_message']='Escribir mensaje';
	$lang['remove_thread']='Eliminar hilo';
	$lang['are_you_sure_want_delete_this_thread_']='¿Seguro que desea eliminar este hilo?';
	$lang['thread_deleted']='Hilo eliminado';
	$lang['send']='Enviar';
	$lang['message_not_sent']='Mensaje no enviado';
	$lang['new_messages']='%s de nuevos mensajes';

 ?>