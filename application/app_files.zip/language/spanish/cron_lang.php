<?php 
	$lang['payment_notification']='Tiene que  pagar el #amount# para "#fee_name#" #fee_description# vencimiento #until#. Haga click <a href="#base_url#payments/pay/#id#">here to pay</a>';
	$lang['payment_subject']='Nueva factura a pagar';
	$lang['payment_email']='Hola #user#,<br><br>Tiene que pagar #amount# de "#fee_name#" #fee_description# vencimiento #until#. Haga click aquí para pagar - <a href="#base_url#payments/pay/#id#">#base_url#payments/pay/#id#</a><br><br>#school_name#<br>';
	$lang['new_message_subject']='Nuevos mensajes en %s';
	$lang['new_message_email']='Hola #user#,<br/><br/>Tiene un nuevo mensaje desde #from# about "#message_subject#".<p>#message#<p/>.<br/>Click here - <a href="#base_url#messages/thread/#id#">#base_url#messages/thread/#id#<a/> -  para ver y responder a este mensaje<br/><br/>#school_name#<br/>';

 ?>