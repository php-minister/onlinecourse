<?php
    $lang['login']='Login';
    $lang['your_email']='Su email';
    $lang['your_password']='Su contraseña';
    $lang['sign_in']='Registro';
    
    $lang['going_to_dashboard']='Ir al panel de control';
    $lang['wrong_email_or_password']='Email o contraseña erróneo';
    $lang['invite_not_found']='Invitación no encontrada';
    
    $lang['set_password']='Establecer contraseña';
    $lang['password']='Contraseña';
    $lang['password_again']='Contraseña de nuevo';
    $lang['set_password']='Establecer contraseña';
    $lang['code']='Código';
    $lang['password_set']='Contraseña establecida con éxito';
    
    $lang['accept_invite']='Aceptar invitar';
?>