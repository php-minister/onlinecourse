<?php 
	$lang['are_you_sure_want_delete_this_classroom_']='¿Está seguro que desea eliminar esta clase?';
	$lang['classroom_deleted']='Clase eliminada';
	$lang['add_classroom']='Añadir clase';
	$lang['classroom']='Clase';
	$lang['edit_classroom']='Editar clase';
	$lang['classroom_scheduling']='Programación de la clase';
	$lang['delete_classroom']='Eliminar clase';
	$lang['new_classroom']='Nueva clase';
	$lang['classroom_name']='Nombre de la clase';
	$lang['scheduling']='Programación para %s';
	$lang['classroom_already_in_use']='Clase actualmente en uso';
 ?>