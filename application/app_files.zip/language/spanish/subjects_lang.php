<?php 
	$lang['are_you_sure_want_delete_this_subject_']='¿Está seguro que desea eliminar esta asignatura?';
	$lang['subject_deleted']='Asignatura eliminada';
	$lang['add_subject']='Añadir asignatura';
	$lang['subject']='Asignatura';
	$lang['teachers']='Profesores';
	$lang['new_subject']='Nueva asignatura';
	$lang['grades']='Cursos';
	$lang['edit_subject']='Editar asignatura';
	$lang['subject_id']='Identificación de la asignatura';
	$lang['please_check_teachers_and_grades']='Por favor compruebe los profesores y cursos';

 ?>