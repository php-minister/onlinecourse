<?php 
	$lang['children']='Mi hijo';
	$lang['scheduling']='Programación';
	$lang['scheduling_of_my_child']='Programación de mi hijo';
	$lang['incidents_with_my_child']='Incidentes con mi hijo';
	$lang['read_more']='Leer más';
	$lang['hide']='Ocultar';
	$lang['gradebook_of_my_child']='Libro de calificaciones de mi hijo';
	$lang['selected_semester']='Semestre seleccionado';
	$lang['all_marks']='Todas las calificaciones';
	$lang['no_marks_yet']='Su hijo no tiene ninguna nota todavía';
	$lang['attendance_of_my_child']='Asistencia de mi hijo';
	$lang['date_incidents']='Fecha de incidentes';
	$lang['comment_is']='y el comentario es';

 ?>