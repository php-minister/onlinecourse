<?php 
	$lang['scores_changed__do_you_want_to_save_them_']='Resultados cambiados. ¿Desea guardarlos?';
	$lang['are_you_sure_want_to_delete_this_assignment_']='¿Está seguro de que desea eliminar esta asignación?';
	$lang['you_didn_t_change_any_scores']='No cambió ningún resultado';
	$lang['subject']='Asignatura';
	$lang['assignment']='Asignación';
	$lang['new_assignment']='Nueva asignación';
	$lang['edit_assignment']='Editar asignación';
	$lang['remove_assignment']='Eliminar asignación';
	$lang['show_students']='Mostrar estudiantes';
	$lang['show_scale']='Mostrar escala';
	$lang['from_to']='Desde %s a %s';
	$lang['from_group']='Desde grupo %s';
	$lang['previous_semester_completed']='Semestre previo está completado. Por favor, cree uno nuevo.';
	$lang['make_sure_you_made_previous_semester_completed']='Asegúrese de que completó el semestre previo y añadió los resultados finales.';
	$lang['current_semester_completed']='El semestre actual está completado, espere a que comience el siguiente semestre.';
	$lang['all_groups_in']='Todos los grupos dentro';
	$lang['save_scores']='Guardar resultados';
	$lang['only_digits_allowed']='Solo se permiten dígitos';
	$lang['set_id']='Establecer identificación';
	$lang['assignment_date']='Asignar fecha';
	$lang['can_not_change_past_semester']='No puede cambiar el semestre pasado';
	$lang['date_is_out_of_range']='Fecha si está fuera de rango';
	$lang['can_not_delete_assignment']='No puede borrar esta asignación';

 ?>