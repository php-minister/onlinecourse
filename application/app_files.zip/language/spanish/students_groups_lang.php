<?php 
	$lang['groups']='Grupos';
	$lang['are_you_sure_want_delete_this_group_']='¿Está seguro que desea eliminar este grupo?';
	$lang['group_deleted']='Grupo eliminado';
	$lang['add_group']='Añadir grupo';
	$lang['edit_group']='Editar grupo';
	$lang['group_scheduling']='Programación del grupo';
	$lang['delete_group']='Borrar grupo';
	$lang['group_name']='Nombre del grupo';
	$lang['new_group']='Nuevo grupo';
	$lang['group_used']='Grupo ya en uso. Por favor mueva a todos los estudiantes fuera de este grupo';
	$lang['scheduling']='Programación de %s grupos';

 ?>