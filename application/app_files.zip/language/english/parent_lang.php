<?php
  $lang['children']='Children';
  $lang['children']='My children';
  $lang['children']='My children';
  $lang['scheduling']='Scheduling';
  
  
  $lang['scheduling_of_my_child']='Scheduling of my child';
  $lang['incidents_with_my_child']='Incidents with my child';
  $lang['read_more']='Read more';
  $lang['hide']='Hide';
  
  $lang['gradebook_of_my_child']='Gradebook of my child';
  $lang['selected_semester']='Selected semester';
  $lang['all_marks']='All marks';
  $lang['no_marks_yet']='Your child doesn\'t have any grades yet';
  
  $lang['attendance_of_my_child']='Attendance of my child';
  $lang['date_incidents']='Date incidents';
  $lang['comment_is']='and comment is';
?>