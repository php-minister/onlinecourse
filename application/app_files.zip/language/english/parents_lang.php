<?php
    $lang['are_you_sure_want_delete_this_parent_']='Are you sure want delete this parent?';
    $lang['parent_deleted']='Parent deleted';
    $lang['add_parent']='Add parent';
    
    $lang['parents_all']="Showing '+iStart+' to '+iEnd+' of '+iTotal+' all parents";
    $lang['parents_filtered']="Showing '+iStart+' to '+iEnd+' of '+iTotal+' parents (filtered from '+iMax+' total parents)";
    
    $lang['new_parent']='New parent';
    $lang['parent_name']='Parent name';
    $lang['children']='Children';
    
    $lang['edit_parent']='Edit parent';
    $lang['delete_parent']='Delete parent';
    
    $lang['parent_not_found']='Parent not found';
?>
