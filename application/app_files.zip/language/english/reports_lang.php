<?php
    $lang['select_teacher']='Select teacher';
    $lang['teacher']='Teacher';
    $lang['feedback']='Feedback';
    
    $lang['select_student']='Select student';
    $lang['lesson']='Lesson';
    $lang['with_comment']=' with comment: ';
    
    $lang['donation']='Donation';
    $lang['donor']='Donor';
    $lang['donated']='Donated';
    $lang['payment']='Payment';
	
    $lang['fee']='Fee';
    
    $lang['select_fee']='Select fee';
    $lang['not_paid_yet']='Not paid yet';
?>