<?php
    $lang['groups']='Groups';
    $lang['are_you_sure_want_delete_this_group_']='Are you sure want delete this group?';
    $lang['group_deleted']='Group deleted';
    $lang['add_group']='Add group';
    $lang['edit_group']='Edit group';
    $lang['group_scheduling']='Group scheduling';
    $lang['delete_group']='Delete group';
    
    $lang['edit_group']='Edit group';
    $lang['group_name']='Group name';

    $lang['new_group']='New group';
    
    $lang['group_used']='Group already in use. Please move out all students from this group';
    $lang['scheduling']='Scheduling of %s group';
?>