<?php
    $lang['are_you_sure_want_delete_this_incident_']='Are you sure want delete this incident?';
    $lang['incident_deleted']='Incident deleted';
    $lang['add_incident']='Add incident';
    
    $lang['incidents_all']="Showing '+iStart+' to '+iEnd+' of '+iTotal+' all incidents";
    $lang['incidents_filtered']="Showing '+iStart+' to '+iEnd+' of '+iTotal+' incidents (filtered from '+iMax+' total incidents)";
    
    $lang['edit_incident']='Edit incident';
	$lang['view_incident'] = 'Incident Information';
    $lang['delete_incident']='Delete incident';
    $lang['taken_actions']='Taken actions';
    $lang['reported_by']='Reported by';
    
    $lang['new_incident']='New incident';
?>