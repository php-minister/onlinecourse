<?php
    $lang['are_you_sure_want_delete_this_classroom_']='Are you sure want delete this classroom?';
    $lang['classroom_deleted']='Classroom deleted';
    $lang['add_classroom']='Add classroom';
    $lang['classroom']='Classroom';
    $lang['edit_classroom']='Edit classroom';
    $lang['classroom_scheduling']='Classroom scheduling';
    $lang['delete_classroom']='Delete classroom';
    
    $lang['new_classroom']='New classroom';
    $lang['classroom_name']='Classroom name';
    $lang['edit_classroom']='Edit classroom';
    $lang['scheduling']='Scheduling for %s';
    
    $lang['classroom_already_in_use']='Classroom already in use';
?>