<?php
    $lang['messages_center']='Messages center';
    $lang['new_message']='New message';
    $lang['send_message']='Send message';
    $lang['message']='Message';
    $lang['to_all_teachers']='To all teachers';
    $lang['to_all_parents']='To all parents';
    $lang['to_all_students']='To all students';
    
    $lang['all']='All';
    $lang['one_recipient']='Please select at least one recipient';
    $lang['message_sent']='Message sent';
    $lang['last_message']='Last message';
    $lang['by']='by';
    $lang['at']='at';
    $lang['write_message']='Write message';
    $lang['remove_thread']='Remove thread';
    $lang['are_you_sure_want_delete_this_thread_']='Are you sure want delete this thread?';
    $lang['thread_deleted']='Thread deleted';
    $lang['send']='Send';
    $lang['message_not_sent']='Message not sent';
    $lang['message_sent']='Message sent';
    $lang['new_messages']='%s new messages';
?>