<?php
    $lang['given_name']='Given name';
    $lang['middle_initial']='Middle initial';
    $lang['sur_name']='Surname';
    $lang['zip_code']='Zip code';
    
    $lang['grade_desc']='Example Kindergarten - #1, 1st Grade - #2, ... 12th Grade - #13';
    $lang['given_name_desc']='';
    $lang['middle_initial_desc']='';
    $lang['sur_name_desc']='';
    $lang['birth_date_desc']='';
    $lang['gender_desc']='';
    $lang['ssn_desc']='';
    $lang['address_desc']='';
    $lang['city_desc']='';
    $lang['state_desc']='';
    $lang['zip_code_desc']='';
    $lang['home_phone_desc']='';
    $lang['cell_phone_desc']='';
    $lang['email_desc']='';

    
    
    $lang['import']='Import';
    $lang['import_data']='Import data';
    $lang['data_type']='Data type';
    $lang['parents']='Parents';
    $lang['teachers']='Teachers';
    $lang['file']='File';
    $lang['csv_options']='CSV options';
    $lang['delimiter']='Delimiter';
    $lang['enclosure']='Enclosure';
    $lang['escape']='Escape';
    $lang['skip_data_from_first_line']='Skip data from first line';
    $lang['import']='Import';
    $lang['skip']='Skip';
    
    $lang['example']='Example';
    $lang['person_s_field']='Person\'s field';
    $lang['column_from_file']='Column from file';
    $lang['process_file']='Process file';

    $lang['wrong_data_type']='Wrong data type';
    $lang['nothing_to_upload']='Nothing to upload';
    $lang['nothing_to_import']='Nothing to import';
    $lang['imported']='Imported';
    $lang['can_not_upload_file']='Can not upload file';
    $lang['can_not_open_imported_file']='Can not open imported file';
    $lang['can_not_split']='Can not split data from line. Please check that you set same delimiter as in a file';
?>