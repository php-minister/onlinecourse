<?php
    $lang['are_you_sure_want_delete_this_student_']='Are you sure want delete this student?';
    $lang['student_deleted']='Student deleted';
    $lang['add_student']='Add student';
    $lang['students_all']="Showing '+iStart+' to '+iEnd+' of '+iTotal+' all students";
    $lang['students_filtered']="Showing '+iStart+' to '+iEnd+' of '+iTotal+' students (filtered from '+iMax+' total students)";
    
    $lang['edit_student']='Edit student';
    $lang['new_student']='New student';
    $lang['delete_student']='Delete student';
    $lang['main']='Main';
    $lang['details']='Details';
    
    $lang['graduated']='Graduated';
    $lang['left_the_school']='Left the school';
    
    $lang['student_name']='Student name';
    
    $lang['parents']='Parents';
    $lang['previous_group_is']='Previous group is';
    
    $lang['student_not_found']='Student not found';
    $lang['part_of_donation']='Donation %';
?>