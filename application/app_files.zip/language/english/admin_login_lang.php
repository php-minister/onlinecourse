<?php
  $lang['login']='Login';
  $lang['password']='Password';
  $lang['going_to_dashboard']='Going to dashboard';
  $lang['login_password_wrong']='Login/password is wrong';
?>