<?php 
    $lang['dashboard']='Dashboard';
    $lang['dashboard_is_coming']='Dashboard is coming';
?>