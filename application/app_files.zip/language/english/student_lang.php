<?php
    $lang['incidents']='My incidents';
    $lang['incidents']='My incidents';
    $lang['gradebook']='My gradebook';
    $lang['library']='Library';
    $lang['read_more']='Read more';
    $lang['hide']='Hide';
    
    $lang['scheduler']='Scheduler';
    
    $lang['gradebook']='My gradebook';
    $lang['selected_semester']='Selected semester';
    $lang['no_grades_yet']='Your don\'t have any grades yet';
    $lang['all_marks']='All marks';
    
    $lang['leave_feedback']='Leave feedback about teacher';
    $lang['feedback']='Feedback';
    
    $lang['not_involved']='You not involved in this lesson';
    $lang['was_absent']='You was absent during this lesson';
    $lang['rating']='Rating';
    $lang['comment']='Comment';
    $lang['feedback_added']='Feedback added';
    $lang['nothing_to_add']='Nothing to add';
    
    $lang['raty_hints']='["bad","poor","regular","good","gorgeous"]';
    $lang['raty_cancel_hint']='Cancel this rating!';
    $lang['raty_not_rated']='Not rated yet!';
    
    $lang['item']='Item';
    $lang['uploaded']='Uploaded';
?>