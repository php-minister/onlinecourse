<?php
    $lang['are_you_sure_want_delete_this_subject_']='Are you sure want delete this subject?';
    $lang['subject_deleted']='Subject deleted';
    $lang['add_subject']='Add subject';
    $lang['subject']='Subject';
    $lang['teachers']='Teachers';
    
    $lang['new_subject']='New subject';
    $lang['grades']='Grades';
    
    $lang['edit_subject']='Edit subject';
    
    $lang['subject_id']='Subject id';
    
    $lang['please_check_teachers_and_grades']='Please check teachers and grades';
?>