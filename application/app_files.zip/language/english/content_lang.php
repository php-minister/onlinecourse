<?php
  $lang['add_item']='Add item';
  $lang['item']='Item';
  $lang['uploaded']='Uploaded';
  $lang['edit_item']='Edit item';
  $lang['delete_item']='Delete item';
  $lang['new_item']='New item';
  $lang['file']='File';
  $lang['description']='Description';
  $lang['access_for']='Access for';
  $lang['for_all']='Everyone can download';
  $lang['can_download']='Can download';
  $lang['one_type']='At least one recipient must be added';
  $lang['allowed_files']='Allowed files to upload';
  $lang['max_file_size']='Max file size';
  
  $lang['edit_item']='Edit item';
  
  $lang['wrong_type']='Wrong access type';

  $lang['are_you_sure_want_delete_this_item_']='Are you sure want delete this item?';
  $lang['item_deleted']='Item deleted';
?>