<?php
  $lang['payment_notification']='You need to pay #amount# for "#fee_name#" #fee_description# due #until#. Click <a href="#base_url#payments/pay/#id#">here to pay</a>';
  $lang['payment_subject']='New invoice for payment';
  $lang['payment_email']='Hello #user#,<br/><br/>You need to pay #amount# for "#fee_name#" #fee_description# due #until#. Click here to pay - <a href="#base_url#payments/pay/#id#">#base_url#payments/pay/#id#</a><br/><br/>#school_name#<br/>';
  
  
  $lang['new_message_subject']='New message in %s';
  $lang['new_message_email']='Hello #user#,<br/><br/>You got new message from #from# about "#message_subject#".<p>#message#<p/>.<br/>Click here - <a href="#base_url#messages/thread/#id#">#base_url#messages/thread/#id#<a/> -  to view and reply to this message<br/><br/>#school_name#<br/>';
?>