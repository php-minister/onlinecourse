<?php
    $lang['login']='Login';
    $lang['your_email']='Your email';
    $lang['your_password']='Your password';
    $lang['sign_in']='Sign in';
    
    $lang['going_to_dashboard']='Going to dashboard';
    $lang['wrong_email_or_password']='Wrong email or password';
    $lang['invite_not_found']='Invite not found';
    
    $lang['set_password']='Set password';
    $lang['password']='Password';
    $lang['password_again']='Password again';
    $lang['set_password']='Set password';
    $lang['code']='Code';
    $lang['password_set']='Password successfully set';
    
    $lang['accept_invite']='Accept invite';
?>