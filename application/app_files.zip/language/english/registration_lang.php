<?php
  $lang['registration']='Registration';
  $lang['send']='Send';
  $lang['phone']='Phone';
  $lang['email']='Email';
  $lang['comment']='Comment';
  
  $lang['email_used']='Email used';
?>