<?php
  $lang['check_start_end_time']='Please check start and end time of lesson';
  $lang['start_time_must_be_bigger']='Start time must be bigger than end time';
  $lang['end_time_lower']='End time  is lower than now';
  
  $lang['room_is_busy']='Room is busy at this time';
  $lang['teacher_is_busy']='Teacher is busy at this time';
  $lang['grade_is_busy']='Grade is busy at this time';
  
  $lang['found___free_rooms']='Found %s free rooms';
  $lang['all_rooms_are_busy']='All rooms are busy';
  
  $lang['lesson_id']='Lesson id';
  $lang['teacher_id']='Teacher id';
  $lang['start_date']='Start date';
  $lang['lesson_start']='Lesson start';
  $lang['lesson_end']='Lesson end';
  $lang['subject']='Subject';
  $lang['room']='Room';
  $lang['lesson_not_removed']='Lesson not removed';
?>