<?php
     $lang['staff']='Staff';
     $lang['are_you_sure_want_delete_this_employee_']='Are you sure want delete this employee?';
     $lang['employee_deleted']='Employee deleted';
     $lang['add_employee']='Add employee';
     $lang['login']='Login';
     
     $lang['new_employee']='New employee';
     $lang['employee_name']='Employee name';
     $lang['employee_login']='Employee login';
     $lang['employee_password']='Employee password';
     $lang['employee_password_again']='Password again';
     $lang['permissions']='Permissions';
     
     $lang['import']='Import data';
     $lang['import_description']='Import students, parents and teachers from CSV file';
     
     $lang['messages_center']='Send mass messages';
     $lang['messages_center_description']='Send message to everyone in your school';
     
     $lang['fees_description']='Manage fees and view payments';
     
     $lang['registrations_description']='Manage registration requests';
     
     $lang['settings_description']='Manage settings, classrooms and semesters';
     
     $lang['students_description']='Manage students, parents, groups, attendance and incidents';
     
     $lang['teachers_description']='Manage teachers, scheduling, subjects and gradebook';
     
     $lang['users_description']='Manage users and staff';
     
     $lang['login_is_busy']='Login is busy';
     
     $lang['edit_employee']='Edit employee';
?>