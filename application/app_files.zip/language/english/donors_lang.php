<?php
  
  $lang['are_you_sure_want_delete_this_donor_']='Are you sure want delete this donor?';
  $lang['donor_deleted']='Donor deleted';
  $lang['add_donor']='Add donor';
  
  $lang['donors_all']="Showing '+iStart+' to '+iEnd+' of '+iTotal+' all donors";
  $lang['donors_filtered']="Showing '+iStart+' to '+iEnd+' of '+iTotal+' donors (filtered from '+iMax+' total donors)";
  
  $lang['new_donor']='New donor';
  $lang['donor_name']='Donor name';
    
  $lang['edit_donor']='Edit donor';
  $lang['delete_donor']='Delete donor';
    
  $lang['donor_not_found']='Donor not found';
  
  $lang['make_donation']='Make donation';
  $lang['donate']='Donate';
  $lang['donor_name']='Donor name';
  $lang['donation']='Donation';
  $lang['comment']='Comment';
  $lang['donation_made']='Donation made';
?>