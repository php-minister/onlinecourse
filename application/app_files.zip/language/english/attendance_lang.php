<?php
  $lang['can_t_find_grades']='Can\'t find grades';
  $lang['show_students']='Show students';
  
  $lang['can_t_find_subjects']='Can\'t find subjects';
  $lang['starts_at']='starts at';
  
  $lang['attendance_1']='Present';
  $lang['attendance_2']='Absent';
  $lang['attendance_3']='Absent w/ excuse';
  $lang['attendance_4']='Tardy';
  $lang['attendance_5']='Tardy w/ excuse';
  
  $lang['no_comments']='No comments';
  $lang['wrong_attendance_status']='Wrong attendance status';
  
  $lang['comments']='Comments';
  $lang['comment']='Comment';
  $lang['private_comment']='Private comment';
?>