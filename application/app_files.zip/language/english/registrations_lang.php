<?php
  $lang['default']='Default';
  $lang['registrations']='Registrations';
  $lang['form']='Form';
  $lang['comment']='Comment';
  
  $lang['view_details']='View details';
  $lang['registration_details']='Registration details';
  $lang['accept']='Accept';
  $lang['decline']='Decline';
  $lang['phone']='Phone';
  $lang['add_comment']='Add comment';
  $lang['comment_added']='Comment added';
  $lang['student_moved']=', student moved to %s, %s group';
  
  $lang['Open']='Open';
  $lang['Accepted']='Accepted';
  $lang['Declined']='Declined';
  
  $lang['registration_not_active']='Registration not active';
  $lang['email_used']='Email used';
?>