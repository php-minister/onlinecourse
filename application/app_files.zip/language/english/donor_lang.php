<?php
  $lang['donate']='Donate';
  $lang['donated']='Total money donated';
  $lang['remaining']='Remaining money';
  $lang['amount']='Amount';
  $lang['fee']='Fee';
  $lang['donating']='Donating';
  $lang['donated_money']='Your donated money';
  $lang['donation']='Donation';
  $lang['donation_date']='Date';
  $lang['source']='Source';
  $lang['manual']='Manual';
  $lang['paid']='Paid';
  $lang['donor_name'] = 'Donor Name';
  $lang['donation_for']='Donation for';
  $lang['donated_to_student'] = 'Total Donated to Students';
  $lang['assinged_students'] = 'Total Students';
?>